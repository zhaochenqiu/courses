# MINE-Mutual-Information-Neural-Estimation-
A pytorch implementation of [MINE(Mutual Information Neural Estimation)](https://arxiv.org/abs/1801.04062) 
